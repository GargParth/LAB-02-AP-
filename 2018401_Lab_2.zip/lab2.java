import java.util.*;
import java.lang.Math;

//Defining interfaces
interface person
{
    void printReward();
    void ShowDetails();
    void ShowMenu();
    void SearchPdct(Company comp);
}


class Item
{

    //for offer mapping
    // 0 : No Offer on product
    // 1 : BOGO (Buy One Get One Free)
    // 2 : 25% off
    private static int lastID;
    private int Id;
    private String ItemName;
    private Float ItemPrice;
    private int AvailableQuantity;
    private String ItemCategory;
    private int Offer;
    private Merchant Seller;

    //define Getters and setters Now
    
    /**
     * @return the lastID
     */
    public static int getLastID() {
        return lastID;
    }

    /**
     * @param lastID the lastID to set
     */
    public static void setLastID(int lastID) {
        Item.lastID = lastID;
    }

    /**
     * @return the availableQuantity
     */
    public int getAvailableQuantity() {
        return AvailableQuantity;
    }

    /**
     * @return the id
     */
    public int getId() {
        return Id;
    }

    /**
     * @return the itemCategory
     */
    public String getItemCategory() {
        return ItemCategory;
    }

    /**
     * @return the itemName
     */
    public String getItemName() {
        return ItemName;
    }

    /**
     * @return the itemPrice
     */
    public Float getItemPrice() {
        return ItemPrice;
    }

    /**
     * @return the offer
     */
    public int getOffer() {
        return Offer;
    }

    /**
     * @return the seller
     */
    public Merchant getSeller() {
        return Seller;
    }

    /**
     * @param availableQuantity the availableQuantity to set
     */
    public void setAvailableQuantity(int availableQuantity) {
        AvailableQuantity = availableQuantity;
    }


    /**
     * @param offer the offer to set
     */
    public void setOffer(int offer) {
        Offer = offer;
    }

    Item(String itemname, Float itemprice, int availableQuantity, String itemCat, Merchant seller)
    {
        //Constructor for the class Item
        this.Id = getLastID()+1;
        setLastID(this.getId());
        this.ItemName = itemname;
        this.ItemPrice = itemprice;
        this.AvailableQuantity = availableQuantity;
        this.ItemCategory = itemCat;
        this.Offer = 0;
        this.Seller = seller;
    }
}





// Defining classes

//Creating a class to store the order and its price in the cart
class order
{
    private Item item;
    private Float Price;
    private int Quantity;

    order(Item name, Float money, int quant)
    {
        this.item = name;
        this.Price = money;
        this.Quantity = quant;
    }

    /**
     * @return the quantity
     */
    public int getQuantity() {
        return Quantity;
    }

    /**
     * @return the item
     */
    public Item getItem() {
        return item;
    }

    /**
     * @return the price
     */
    public Float getPrice() {
        return Price;
    }
}

class Cart
{
    private ArrayList<order> myItems; //all the items in the cart

    /**
     * @return the myItems
     */
    public ArrayList<order> getMyItems() {
        return myItems;
    }


    Cart()
    {
        myItems = new ArrayList<order>();
    }
    
    //Create a function to add an item to the cart
    public void addToCart(Item myitem, int itemquantity)
    {
        //add item to the arraylist of items for this cart
        //then update the total cart price
        Float tempPrice = myitem.getItemPrice();
        //check for offers
        switch(myitem.getOffer())
        {
            case 0: //No offer on this item
                    tempPrice=Float.parseFloat(String.valueOf(tempPrice*itemquantity));
                    break;
            case 1: //BOGO offer applies
                    //check the itemQuantity
                    tempPrice = Float.parseFloat(String.valueOf(tempPrice * Math.ceil((itemquantity/2))));
                    break;
            case 2: //25% Discount applies
                    tempPrice = tempPrice*itemquantity;
                    tempPrice=Float.parseFloat(String.valueOf(tempPrice*0.75));
                    break;
        }

        //add 0.5% tax on the final value;
        tempPrice = Float.parseFloat(String.valueOf(tempPrice*1.005));
        
        
        //Create a new Order type object and add it to your list of orders
        order Myorder = new order(myitem, tempPrice, itemquantity);
        myItems.add(Myorder);
    }
}




class Customer implements person
{
    //The instance Variables declared ahead
    private int RewardEarned;
    private Float MainAccount;
    private String custName;
    private Cart custCart;
    private ArrayList<order> myOrders;
    private int PurchaseNo;
    private int custID;
    private static int Last_id=0;
    private String ADR;
    private int total_orders;

    Customer(String Name, String address)
    {
        this.custName = Name;
        this.RewardEarned=0;
        this.MainAccount = Float.parseFloat("100");
        custCart = new Cart();
        myOrders = new ArrayList<order>();
        PurchaseNo = 0;
        custID = getLast_id()+1;
        setLast_id(getCustID()+1);
        ADR = address;
        total_orders=0;
    }


    /**
     * @return the aDR
     */
    public String getADR() {
        return ADR;
    }

    /**
     * @return the total_orders
     */
    public int getTotal_orders() {
        return total_orders;
    }

    /**
     * @param total_orders the total_orders to set
     */
    public void setTotal_orders(int total_orders) {
        this.total_orders = total_orders;
    }

    //getters and setters declared ahead
    /**
     * @return the last_id
     */
    public static int getLast_id() {
        return Last_id;
    }

    /**
     * @param last_id the last_id to set
     */
    public static void setLast_id(int last_id) {
        Last_id = last_id;
    }

    /**
     * @return the custID
     */
    public int getCustID() {
        return custID;
    }

    /**
     * @param rewardEarned the rewardEarned to set
     */
    public void setRewardEarned(int rewardEarned) {
        RewardEarned = rewardEarned;
    }

    /**
     * @return the purchaseNo
     */
    public int getPurchaseNo() {
        return PurchaseNo;
    }

    /**
     * @param purchaseNo the purchaseNo to set
     */
    public void setPurchaseNo(int purchaseNo) {
        PurchaseNo = purchaseNo;
    }

    /**
     * @return the custName
     */
    public String getCustName() {
        return custName;
    }

    /**
     * @return the custCart
     */
    public Cart getCustCart() {
        return custCart;
    }

    /**
     * @return the myOrders
     */
    public ArrayList<order> getMyOrders() {
        return myOrders;
    }

    /**
     * @return the mainAccount
     */
    public Float getMainAccount() {
        return MainAccount;
    }

    /**
     * @return the rewardEarned
     */
    public int getRewardEarned() {
        return RewardEarned;
    }

    /**
     * @param mainAccount the mainAccount to set
     */
    public void setMainAccount(Float mainAccount) {
        MainAccount = mainAccount;
    }



    //class functions defined ahead
    public void add_purchased_order_to_list(order o)
    {
        //Add the new order to the head of the list
        myOrders.add(0, o);;

        //check the length of this list, if greater than 10, remove the last element
        if(myOrders.size()>10)
        {
            //we need to store only the last 10 purchases, remove the purchase at the tail of this deque
            myOrders.remove(myOrders.size()-1);
        }
    }


    public void List_recent_orders()
    {
        for (order o : myOrders)
        {
            System.out.println("Bought item "+o.getItem().getItemName());
            System.out.println("Quantity : "+o.getQuantity()+" For RS. "+o.getPrice());
            System.out.println("From Merchant "+o.getItem().getSeller().getMerchantName());
            System.out.println();
        }
    }




    //Interface functions defined ahead
    @Override
    public void printReward()
    {
        System.out.println("\n");
        System.out.println("Total Amount of Reward Won : "+ this.getRewardEarned());
    }


    @Override
    public void ShowMenu()
    {
        System.out.println();
        System.out.println("\t\t WELCOME "+this.getCustName().toUpperCase() +"\t");
        System.out.println("\t CUSTOMER MENU");
        System.out.println("\t 1. Search Item \t");
        System.out.println("\t 2. Checkout Cart \t");
        System.out.println("\t 3. Reward Won \t");
        System.out.println("\t 4. Print Latest Orders \t");
        System.out.println("\t 5. Exit \t");
        System.out.println();
    }

    @Override
    public void ShowDetails()
    {
        System.out.println();
        System.out.println("\t Customer name : "+getCustName());
        System.out.println("\t Customer ID   : "+getCustID());
        System.out.println("\t Address : "+this.getADR());
        System.out.println("\t Total Orders placed : "+this.getTotal_orders());
    }

    @Override
    public void SearchPdct(Company comp)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println();
        System.out.println("\t SELECT A CATEGORY \t");
        System.out.println();
        ArrayList<String> cat = comp.getCategories();
        
        for(String s : cat)
        {
            System.out.println("-> "+ s );
        }

        String category_choice = sc.nextLine().toUpperCase();

        ArrayList<Item> product_list = comp.getProduct_list();
        System.out.println();
        System.out.println("\t ITEMS UNDER YOUR CHOSEN CATEGORY :-");

        for ( Item product : product_list )
        {
            if(category_choice.equals(product.getItemCategory().toUpperCase()))
            {
                // the category required and that of the product is the same
                //display the details of the required product
                System.out.print("-> "+product.getId()+"  "+product.getItemName()+"  "+product.getItemPrice()+"  ");
                int choice = product.getOffer();
                switch(choice)
                {
                    case 0 : break;
                    case 1 ://BOGO OFFER APPLIES
                            System.out.println("Buy One Get one Free");
                            break;
                    case 2 ://25% off applies
                            System.out.println("25% off");
                            break;
                    default: break;
                }
            }
        }

        //All items Displayed
        //Show The menu to buy, add to cart or exit


        System.out.println("\t CHOOSE AN OPTION \t");
        System.out.println("\t 1. Buy Item");
        System.out.println("\t 2. Add Item to Cart");
        System.out.println("\t 3. exit");

        int choice = Integer.parseInt(sc.nextLine());
        switch (choice)
        {
            case 1 ://Buy a single Item
                    System.out.println("Enter Item Code");
                    int icode = Integer.parseInt(sc.nextLine());
                    System.out.println("Enter Quantity");
                    int iquant = Integer.parseInt(sc.nextLine());
                    Float available_balance = this.getMainAccount();
                    Item itermReq = null;
                    for ( Item i : comp.getProduct_list() )
                    {
                        if(i.getId()==icode)
                        {
                            itermReq = i;
                        }
                    }
                    Float iprice = itermReq.getItemPrice();
                    int offer = itermReq.getOffer();
                    Float fin_price=Float.parseFloat(String.valueOf( iprice*iquant*(1.005) ));
                    //Apply any applicable offer
                    switch(offer)
                    {
                        case 1 : fin_price = Float.parseFloat(String.valueOf(iprice*(1.005)*(Math.ceil(iquant/2))));
                                break;
                        case 2 : fin_price = Float.parseFloat(String.valueOf(iprice*(1.005)*(0.75)));
                                break;
                    }

                    if(available_balance>=fin_price)
                    {
                        if(itermReq.getAvailableQuantity()>=iquant)
                        {
                            //everything is fine;
                            //Generate Order
                            order o = new order(itermReq, fin_price, iquant);

                            //deduct money
                            this.setMainAccount(getMainAccount()-o.getPrice());
                            itermReq.setAvailableQuantity(itermReq.getAvailableQuantity()-iquant);
                            comp.setTotalEarnings(comp.getTotalEarnings()+(o.getPrice()*(1.005)));
                            Merchant merch = itermReq.getSeller();
                            merch.setTotalSales(Float.parseFloat(String.valueOf(merch.getTotalSales()+o.getItem().getItemPrice()*(o.getQuantity()*(1.01)))));
                            merch.setSales(o.getPrice()-o.getItem().getItemPrice()+merch.getSales());
                            if(merch.getSales()>=merch.getReward_sales())
                            {
                                merch.setSlotCapacity(merch.getSlotCapacity()+1);
                                merch.setSales(merch.getSales()-merch.getReward_sales());
                            }
                            this.setPurchaseNo(getPurchaseNo()+1);
                            if(this.getPurchaseNo()>=5)
                            {
                                this.setMainAccount(getMainAccount()+10);
                                this.setRewardEarned(getRewardEarned()+10);
                                this.setPurchaseNo(0);
                            }
                            this.add_purchased_order_to_list(o);
                            this.setTotal_orders(getTotal_orders()+1);
                            comp.setTotalEarnings((fin_price/(1.005))*1.01);
                        }
                        else
                        {
                            System.out.println("\n\t ERROR : CANNOT BUY ITEM "+ itermReq.getItemName()+", OUT OF STOCK \t");
                        }
                    }
                    else
                    {
                        System.out.println("\n\t ERROR : CANNOT BUY ITEM" + itermReq.getItemName() +", INSUFFICIENT BALANCE \t");
                    }
                    break;

            case 2 ://add items to cart
                    Cart mycart = getCustCart();
                    char adder = 'Y';
                    System.out.println();
                    System.out.println("\t\t ADD ITEMS TO TOUR CART \n");
                    while(adder=='y' || adder == 'Y')
                    {
                        System.out.println("\t Enter Item Code ");
                        int code = Integer.parseInt(sc.nextLine());
                        System.out.println("\t Enter Quantity ");
                        int quant = Integer.parseInt(sc.nextLine());
                        System.out.println();
                        Item it = null;
                        for(Item ite : comp.getProduct_list())
                        {
                            if(code==ite.getId())
                            {
                                it = ite;
                            }
                        }

                        mycart.addToCart(it, quant);
                        System.out.println("Want to add More ? (y/n)");
                        adder = sc.nextLine().charAt(0);
                    }
                    break;

            case 3 : break;
        }
    //Customer Searching function ends here
    }

    public int Checkout(Cart custcart, Company comp)
    {
        //Succesfull checkout of all items : return 1
        //Insufficient account balance : return -1
        ArrayList<order> toRemove = new ArrayList<order>();
        
        for (order o : custcart.getMyItems())
        {
            Float availableBalance = getMainAccount();
            Float order_price = o.getPrice();
            
            if(availableBalance>order_price)
            {
                //The customer can afford to buy this order

                //check if enough items are available with the company
                if(o.getQuantity()<=o.getItem().getAvailableQuantity())
                {
                    //Enough items are available with the company
                    //deduct cash
                    //change avialable balance of items with company

                    availableBalance = availableBalance - order_price;
                    o.getItem().setAvailableQuantity(o.getItem().getAvailableQuantity() - o.getQuantity());

                    //Handle rewards For Customer
                    this.setPurchaseNo(getPurchaseNo()+1);
                    if(this.getPurchaseNo()==5)
                    {
                        this.setMainAccount(getMainAccount()+10);
                        this.setRewardEarned(getRewardEarned()+10);
                        this.setPurchaseNo(0);
                    }

                   
                    //Handle Rewards for the Merchant
                    Merchant orderMerch = o.getItem().getSeller();
                    orderMerch.setSales(o.getPrice()+orderMerch.getSales()-o.getItem().getItemPrice());
                    orderMerch.setTotalSales(Float.parseFloat(String.valueOf(orderMerch.getTotalSales()+(o.getItem().getItemPrice()*o.getQuantity()*(1.01)))));
                    if(orderMerch.getSales() >= orderMerch.getReward_sales())
                    {
                        //merchant is elligible for an extra slot
                        orderMerch.setSlotCapacity(orderMerch.getSlotCapacity()+1);
                        orderMerch.setSales(orderMerch.getSales()-orderMerch.getReward_sales());

                    }

                    //Purchase succesfull
                    //add this purchase to the list of purchases of the customer
                    this.add_purchased_order_to_list(o);

                    //Update the company profits from the order
                    //calculate the amount company gets, add the transaction fees from the merchant too
                    Float companyPrice = Float.parseFloat(String.valueOf((o.getPrice()/(1.005))*(1.01)));
                    comp.setTotalEarnings(comp.getTotalEarnings()+companyPrice);

                    //remove this order from myItems
                    toRemove.add(o);
                    this.setTotal_orders(getTotal_orders()+1);
                }
                else
                {
                    System.out.println("\n\t ERROR : CANNOT CHECKOUT ITEM " + o.getItem().getItemName() +", OUT OF STOCK \t");
                }

                this.setMainAccount(availableBalance);
            }
            else
            {
                System.out.println("\n\t ERROR : CANNOT CHECKOUT ITEM " + o.getItem().getItemName() +", INSUFFICIENT BALANCE \t");
                return -1;
            }
        }


        for(order x : toRemove)
        {
            custcart.getMyItems().remove(x);
        }

        return 1;
        
    }





}


class Merchant implements person
{
    //fill this class
    private int ID;
    private static int last_ID;
    private Float totalSales;
    private Float Sales;
    private int slotCapacity;
    private Float reward_sales;
    private String MerchantName;
    private String ADR;


    //defining The constructor
    Merchant(String name, String address)
    {
        this.MerchantName = name;
        this.ID = getLast_ID()+1;
        setLast_ID(this.getID()+1);
        totalSales = Float.valueOf("0") ;
        Sales=Float.valueOf("0");
        slotCapacity=10;
        reward_sales=Float.valueOf("100");
        this.ADR = address;
    }


    /**
     * @return the aDR
     */
    public String getADR() {
        return ADR;
    }

    /**
     * @return the last_ID
     */
    public static int getLast_ID() {
        return last_ID;
    }

    /**
     * @param last_ID the last_ID to set
     */
    public static void setLast_ID(int last_ID) {
        Merchant.last_ID = last_ID;
    }

    /**
     * @return the merchantName
     */
    public String getMerchantName() {
        return MerchantName;
    }

    /**
     * @return the reward_sales
     */
    public Float getReward_sales() {
        return reward_sales;
    }

    /**
     * @param reward_sales the reward_sales to set
     */
    public void setReward_sales(Float reward_sales) {
        this.reward_sales = reward_sales;
    }

    /**
     * @return the slotCapacity
     */
    public int getSlotCapacity() {
        return slotCapacity;
    }

    /**
     * @param slotCapacity the slotCapacity to set
     */
    public void setSlotCapacity(int slotCapacity) {
        this.slotCapacity = slotCapacity;
    }

    /**
     * @return the iD
     */
    public int getID() {
        return ID;
    }

    /**
     * @return the sales
     */
    public Float getSales() {
        return Sales;
    }

    /**
     * @return the totalSales
     */
    public Float getTotalSales() {
        return totalSales;
    }

    /**
     * @param sales the sales to set
     */
    public void setSales(Float sales) {
        Sales = sales;
    }

    /**
     * @param totalSales the totalSales to set
     */
    public void setTotalSales(Float totalSales) {
        this.totalSales = totalSales;
    }



    public void add_offer_to_item(Company comp)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println();
        boolean cont = false;
        for(Item i : comp.getProduct_list())
        {
            if(i.getSeller()==this)
            {
                System.out.print("-> "+i.getId()+"  "+i.getItemName()+"   RS."+i.getItemPrice());
                switch(i.getOffer())
                {
                    case 0 : System.out.println("No offer");
                            break;
                    case 1 : System.out.println("Buy ONe Get One Free");
                            break;
                    case 2 : System.out.println("25% OFF");
                }
                cont = true;
            }
        }

        if(!cont)
        {
            System.out.println("\t Error : You do not have any Items under your account, cannot apply any offers");
            String a = sc.nextLine();
            return;
        }

        System.out.println();
        System.out.println("Enter The ID of product to add offer to");
        int product_code = Integer.parseInt(sc.nextLine());
        System.out.println("Enter the offer to apply ");
        System.out.println("-> 0 for no offer");
        System.out.println("-> 1 for Buy one get one free ");
        System.out.println("-> 2 for 25% OFF");
        int offer_code = Integer.parseInt(sc.nextLine());

        for(Item product : comp.getProduct_list())
        {
            if(product.getId()==product_code)
            {
                product.setOffer(offer_code);
            }
        }

        System.out.println("\t Offer Applied successfully");
    }

    public void Add_items(Company comp)
    {
        Scanner sc = new Scanner(System.in);
        ArrayList<Item> product_list = comp.getProduct_list();
        int item_count=0;
        //Count the number of items that the merchant is selling
        for(Item product : product_list)
        {
            if(getID()==product.getSeller().getID())
            {
                item_count++;
            }
        }

        if(item_count>=getSlotCapacity())
        {
            System.out.println("\t\t ERROR: CANNOT ADD MORE ITEMS, SLOT CAPACITY FULL");
            return;
        }

        else
        {
            System.out.println("\t ENTER ITEM DETAILS : ");
            System.out.println("-> Item Name : ");
            String iName = sc.nextLine();
            System.out.println("-> Item Price : ");
            Float iPrice = Float.parseFloat(sc.nextLine());
            System.out.println("-> Item Quantity : ");
            int iQuant = Integer.parseInt(sc.nextLine());
            System.out.println("-> Item Category : ");
            String iCat = sc.nextLine().toUpperCase();
            Item i = new Item(iName, iPrice, iQuant, iCat.toUpperCase(), this);
            comp.add_item_to_list(i);
        }

    }


    public void Edit_item(Company comp)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println();
        boolean cont = false;

        for( Item product : comp.getProduct_list() )
        {
           if(this.getID()==product.getSeller().getID())
           {
                System.out.print("-> "+product.getId()+"  "+product.getItemName()+"  RS."+product.getItemPrice()+"  ");
                int choice = product.getOffer();
                switch(choice)
                {
                    case 0 : break;
                    case 1 ://BOGO OFFER APPLIES
                            System.out.println("Buy One Get one Free");
                            break;
                    case 2 ://25% off applies
                            System.out.println("25% off");
                            break;
                    default: break;
                }
                cont = true;
           }
        }

        if(cont==false)
            return;

        System.out.println("\t Enter the Item Code of Item to Edit : ");
        int icode = Integer.parseInt(sc.nextLine());
        Item ic = null;
        for( Item pdt : comp.getProduct_list() )
        {
            if(pdt.getId()==icode)
            {
                ic = pdt;
            }
        }

        if(ic == null)
        {
            System.out.println("\t Code Entered not Valid");
        }
        else
        {
            comp.getProduct_list().remove(ic);
        }

        Add_items(comp);
    }




    @Override
    public void printReward()
    {
        System.out.println();
        System.out.println("\t Comgratulations, you won "+(this.getSlotCapacity()-10)+" Under Mercury's reward Scheme");
    }

    @Override
    public void ShowMenu()
    {
        System.out.println("\t\t WELCOME "+this.getMerchantName());
        System.out.println("\t MERCHANT MENU \t");
        System.out.println("\t 1. Add Item \t");
        System.out.println("\t 2. Edit Item \t");
        System.out.println("\t 3. Search By Category \t");
        System.out.println("\t 4. Add Offer \t");
        System.out.println("\t 5. Rewards Won \t");
        System.out.println("\t 6. Exit \t");
        System.out.println();
    }

    @Override
    public void ShowDetails()
    {
        System.out.println();
        System.out.println("\t Merchant Name : "+getMerchantName());
        System.out.println("\t Merchant ID   : "+getID());
        System.out.println("\t Merchent Address : "+getADR());
        System.out.println("\t Total Contribution : "+getTotalSales());
    }


    @Override
    public void SearchPdct(Company comp)
    {

        Scanner sc = new Scanner(System.in);
        System.out.println();
        System.out.println("\t SELECT A CATEGORY \t");
        System.out.println();
        ArrayList<String> cat = comp.getCategories();
        
        for(String s : cat)
        {
            System.out.println("-> "+s.toUpperCase());
        }

        String category_choice = sc.nextLine().toUpperCase();

        ArrayList<Item> product_list = comp.getProduct_list();
        System.out.println();
        System.out.println("\t ITEMS UNDER YOUR CHOSEN CATEGORY :-");

        for ( Item product : product_list )
        {
            if(category_choice.equals(product.getItemCategory().toUpperCase()))
            {
                // the category required and that of the product is the same
                //display the details of the required product
                System.out.print("-> "+product.getId()+"  "+product.getItemName()+"  "+product.getItemPrice()+"  ");
                int choice = product.getOffer();
                switch(choice)
                {
                    case 0 : break;
                    case 1 ://BOGO OFFER APPLIES
                            System.out.println("Buy One Get one Free");
                            break;
                    case 2 ://25% off applies
                            System.out.println("25% off");
                            break;
                    default: break;
                }
            }
        }
        System.out.println();
    }

}



class Company
{
    //class instance variable declared ahead
    private ArrayList<Customer> myCustomers;
    private ArrayList<Merchant> myMerchants;
    private ArrayList<String> categories;
    private ArrayList<Item> product_list;
    private Float TotalEarnings;


    Company()
    {
        myCustomers = new ArrayList<Customer>();
        myMerchants = new ArrayList<Merchant>();
        categories = new ArrayList<String>();
        product_list = new ArrayList<Item>();
        TotalEarnings = Float.parseFloat("0");
    }

    /**
     * @return the product_list
     */
    public ArrayList<Item> getProduct_list() {
        return product_list;
    }

    /**
     * @return the categories
     */
    public ArrayList<String> getCategories() {
        return categories;
    }


    /**
     * @return the myCustomers
     */
    public ArrayList<Customer> getMyCustomers() {
        return myCustomers;
    }

    /**
     * @return the myMerchants
     */
    public ArrayList<Merchant> getMyMerchants() {
        return myMerchants;
    }

    /**
     * @return the totalEarnings
     */
    public Float getTotalEarnings() {
        return TotalEarnings;
    }

    /**
     * @param d the totalEarnings to set
     */
    public void setTotalEarnings(double d) {
        TotalEarnings = Float.parseFloat(String.valueOf(d));
    }


    public void add_item_to_list(Item i)
    {
        product_list.add(i);
        boolean unique = true;
        for ( String s : categories )
        {
            if(s.equals(i.getItemCategory().toUpperCase()))
            {
                unique=false;
            }
        }

        if(unique)
        {
            categories.add(i.getItemCategory().toUpperCase());
        }
    }


    public void add_customer(Customer c)
    {
        myCustomers.add(c);
    }

    public void add_merchant(Merchant m)
    {
        myMerchants.add(m);
    }

}


class lab2
{

    public static void DisplayMainMenu()
    {
        System.out.println();
        System.out.println("\t\t WELCOME TO MERCURY \t\t");
        System.out.println("\t 1. Enter as Merchant \t");
        System.out.println("\t 2. Enter as Customer \t");
        System.out.println("\t 3. See User Details \t");
        System.out.println("\t 4. Company Account Balance \t");
        System.out.println("\t 5. Exit \t");
        System.out.println();
    }


    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int Main_menu_choice = 0;
        Company Mercury = new Company();

        //Creating Merchants
        Merchant a = new Merchant("Jack", "Model Town");
        Merchant b = new Merchant("John","Azadpur");
        Merchant c = new Merchant("James", "Okhla Phase 3");
        Merchant d = new Merchant("Jeff", "Chandni Chowk");
        Merchant e = new Merchant("Joseph", "Noida City Centre");
        Mercury.add_merchant(a);
        Mercury.add_merchant(b);
        Mercury.add_merchant(c);
        Mercury.add_merchant(d);
        Mercury.add_merchant(e);

        //Creating Customers
        Customer c1 = new Customer("Ali", "address");
        Customer c2 = new Customer("Nobby", "Japan");
        Customer c3 = new Customer("Bruno", "Govindpuri");
        Customer c4 = new Customer("Borat", "Kalkaji");
        Customer c5 = new Customer("Aladeen", "Wadia");
        Mercury.add_customer(c1);
        Mercury.add_customer(c2);
        Mercury.add_customer(c3);
        Mercury.add_customer(c4);
        Mercury.add_customer(c5);


        while(Main_menu_choice!=5)
        {
            //main loop of the programme
            DisplayMainMenu();
            //Take User input

            Main_menu_choice = Integer.parseInt(sc.nextLine());

            switch(Main_menu_choice)
            {
                case 1: //Enter as Merchant
                        //Display Merchants
                        System.out.println("Choose A Merchant");
                        for (Merchant m : Mercury.getMyMerchants())
                        {
                            System.out.println("-> "+m.getID()+"  "+m.getMerchantName());
                        }
                        int merchant_choice = Integer.parseInt(sc.nextLine());

                        for( Merchant m :Mercury.getMyMerchants() )
                        {
                            if(m.getID()==merchant_choice)
                            {
                                //stay in this menu while exit is not pressed
                                int merchant_menu_choice = 0;
                                while(merchant_menu_choice!=6)
                                {
                                    m.ShowMenu();
                                    merchant_menu_choice = Integer.parseInt(sc.nextLine());
                                    
                                    switch(merchant_menu_choice)
                                    {
                                        case 1: //merchant wants to add product
                                                m.Add_items(Mercury);
                                                break;
                                        case 2: //merchant wants to edit items
                                                m.Edit_item(Mercury);
                                                break;
                                        case 3: //initiate merchants searchPDT
                                                m.SearchPdct(Mercury);
                                                break;
                                        case 4://add offers to existing product
                                                m.add_offer_to_item(Mercury);
                                                break;
                                        case 5://print reward
                                                m.printReward();
                                    }
                                }
                            }
                        }
                        break;
                case 2 ://Enter as Customer
                        //Display Customers
                        System.out.println("Choose A Customer");
                        for( Customer cust : Mercury.getMyCustomers() )
                        {
                            System.out.println("-> "+cust.getCustID()+"  "+cust.getCustName());
                        }
                        int cutomer_choice = Integer.parseInt(sc.nextLine());

                        for( Customer cu : Mercury.getMyCustomers() )
                        {
                            int customer_menu_choice;
                            if( cu.getCustID() == cutomer_choice )
                            {
                                do
                                {
                                    //Stay in this menu until exit is not pressed
                                    cu.ShowMenu();
                                    customer_menu_choice = Integer.parseInt(sc.nextLine());

                                    switch (customer_menu_choice)
                                    {
                                        case 1://Search Items
                                                cu.SearchPdct(Mercury);
                                                break;
                                        case 2://Checkout Cart
                                                cu.Checkout(cu.getCustCart(), Mercury);
                                                break;
                                        case 3://Reward Won
                                                cu.printReward();
                                                break;
                                        case 4://Print Latest Orders
                                                ArrayList<order> temp = cu.getMyOrders();
                                                for( order o : temp )
                                                {
                                                    System.out.println("-> Bought "+o.getItem().getItemName()+"  quantity "+o.getQuantity()+" for RS."+o.getPrice()+"  from merchant "+o.getItem().getSeller().getMerchantName());
                                                }
                                                break;
                                        case 5 ://Exit
                                                customer_menu_choice = 5;
                                    }
                                }while(customer_menu_choice!=5);
                            }
                        }
                    break;

                case 3 ://View details of Any user
                        System.out.println("Enter M for Merchant And C for Customer");
                        char code = sc.nextLine().charAt(0);
                        
                        
                        if(code=='M' || code == 'm')
                        {
                            System.out.println("\t Choose From The Merchants Below");
                            for(Merchant m : Mercury.getMyMerchants())
                            {
                                System.out.println("-> "+m.getID()+"  "+m.getMerchantName());
                            }
                            int code_id = Integer.parseInt(sc.nextLine());
                            for(Merchant m : Mercury.getMyMerchants())
                            {
                                if(m.getID()==code_id)
                                {
                                    m.ShowDetails();
                                }
                            }
                        }
                        else if(code=='C' || code=='c')
                        {
                            for( Customer cust : Mercury.getMyCustomers())
                            {
                                System.out.println("-> "+cust.getCustID() + "  "+cust.getCustName());                            }
                            int code_id = Integer.parseInt(sc.nextLine());
                            for(Customer cust : Mercury.getMyCustomers() )
                            {
                                if(code_id==cust.getCustID())
                                {
                                    cust.ShowDetails();
                                }
                            }
                        }
                        break;
                case 4 ://Company Account Balance
                        System.out.println();
                        System.out.println("-> Total Earnings of the Company : "+Mercury.getTotalEarnings());
                        break;
                case 5://Exit
                        System.exit(0);
            }

        }
        
    }
}